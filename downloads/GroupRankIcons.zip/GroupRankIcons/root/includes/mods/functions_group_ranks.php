<?php
/** 
*
* @package phpBB3
* @file $Id: functions_group_ranks.php, v 0.0.1
* @copyright (c) 2009 darksnow.co.uk
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/
/**
* @ignore
*/
if(!defined('IN_PHPBB'))
{
	exit;
}

/**
* Create a valid img tag for the group rank image
*/
function getGroupRankImageTag($name, $img)
{
	global $phpbb_root_path, $config;

	return '<img src="' . $phpbb_root_path . $config['ranks_path'] . '/'
           . $img .'" alt="' . $name . '" title="' . $name . '" />';
}

/**
* Get a list of all the group rank images and rank names
* for the given user id
*/
function getGroupRanksArray($userid)
{
	global $db, $template;
	$ret = '';
	$sql = "SELECT rank_title, rank_image FROM phpbb_groups g
			INNER JOIN phpbb_ranks r ON g.group_rank = r.rank_id
			INNER JOIN phpbb_user_group u ON g.group_id = u.group_id
			INNER JOIN phpbb_users us ON us.user_id = u.user_id
			WHERE NOT (us.user_rank = r.rank_id)
			AND u.user_pending = 0 AND u.user_id = $db->sql_escape($userid)
			ORDER BY g.group_name";

	if ($rows = $db->sql_query($sql))
	{
		while ($r = $db->sql_fetchrow($rows))
		{
			$ret .= "\n" . getGroupRankImageTag($r['rank_title'], $r['rank_image']);
		}
	}
	return $ret;
}

?>